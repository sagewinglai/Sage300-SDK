﻿<%@ Application Codebehind="Global.asax.cs" Inherits="ValuedPartner.Sample.Customization.Web.MvcApplication" Language="C#" %>
